package com.test.adharcard_07_04_2020;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EmailAddressUpdate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.email_address_update);
    }
}